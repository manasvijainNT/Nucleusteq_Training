from setuptools import setup, find_packages

setup(
    name="data_processor_task",
    version="1.0.0",
    description="A core Python training assignment porject",
    author="Manasvi Jain",
    packages=find_packages(),
)