class Member:
    def _init_(self, name, email, phone):
        self.name = name
        self.email = email
        self.phone = phone

    def _str_(self):
        return f"Name: {self.name}, Email: {self.email}, Phone: {self.phone}" 
